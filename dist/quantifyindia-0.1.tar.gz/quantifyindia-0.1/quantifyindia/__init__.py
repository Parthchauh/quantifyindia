# quantifyindia/__init__.py

from .nse_data import get_realtime_data
from .historical_data import get_historical_data
